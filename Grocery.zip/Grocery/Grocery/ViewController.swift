//
//  ViewController.swift
//  Grocery
//
//  Created by maram  on 15/06/1444 AH.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

